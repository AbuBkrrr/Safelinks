# SAFE_Links — Sideload Installer (Windows)

Builds a Windows `.exe` installer that puts ADB (Android's
platform-tools) and the unified SAFE_Links APK on someone's PC, with a
one-click Start Menu shortcut that walks them through installing the
app onto a phone over USB — no Play Store listing needed.

This is for the **unified app** (`reslink-unified-android`,
`io.reslink.app` — the one with the "I'm a Reseller / Admin" vs "I'm
pairing a router" picker screen), not the older three separate apps.

This only works on Windows (Inno Setup Compiler is Windows software).
Everything in this folder is source for that build, not the build
itself.

## Two things you need to drop in before compiling

Inno Setup Compiler will fail with a "file not found" error until
both of these exist:

### 1. ADB platform-tools

Download the **Windows** platform-tools ZIP from Google directly:
`https://developer.android.com/tools/releases/platform-tools`

Unzip it, then copy these into this folder's `platform-tools\`
subfolder (create it if needed):

```
platform-tools/
├── adb.exe
├── AdbWinApi.dll        (older Windows only — fine if missing on 10/11)
└── AdbWinUsbApi.dll     (older Windows only — fine if missing on 10/11)
```

Only `adb.exe` is strictly required on modern Windows (10/11); the two
DLLs are for older Windows versions and the `.iss` script already
marks them optional (`skipifsourcedoesntexist`).

**Licensing note:** platform-tools ships under the Android SDK's own
license terms. Redistributing `adb.exe` inside your own installer is
common practice, but you're bundling Google's binary, not something
this project built — keep the license terms in mind for your own
distribution.

### 2. The built APK

From the `reslink-unified-android` project: **Build → Build Bundle(s)
/ APK(s) → Build APK(s)** in Android Studio (use the **release**
variant if you've set up signing — see that project's own README; the
**debug** variant works for internal testing but Android will warn
the person installing it that it's a debug build).

Copy the resulting `.apk` into this folder and name it exactly
`app-release.apk` (or edit the `Source:` line in
`UnifiedSideloadInstaller.iss` to match whatever you named it).

## Compiling

1. Install Inno Setup Compiler: `https://jrsoftware.org/isdl.php`
2. Open `UnifiedSideloadInstaller.iss` in it.
3. **Build → Compile** (or press F9).
4. Output lands in `Output\SAFELinksSideloadSetup.exe`.

## What the person running the installer sees

1. A normal Windows installer wizard — installs to
   `Program Files\SAFE_Links Sideloader\` by default, no admin rights
   required (`PrivilegesRequired=lowest`).
2. At the end, an option (checked by default) to immediately run
   `sideload.bat`, which opens a command-window walkthrough: plug in
   the phone, enable USB debugging, confirm the "Allow this computer"
   prompt on the phone, then it runs `adb install -r` and reports
   success or the specific failure reason.
3. A Start Menu shortcut ("Install SAFE_Links to phone") to re-run
   that same walkthrough any time — for a different phone, or to
   reinstall an update.
4. Once installed on the phone, they'll see the native "I'm a
   Reseller / Admin" vs "I'm pairing a router" picker on first open —
   same as launching the app any other way.

## Before shipping this to anyone

- **Unsigned installer.** Windows SmartScreen will show an "Unknown
  publisher" warning on first run. If you're distributing this beyond
  your own team, get a code-signing certificate and sign the compiled
  `.exe` — Inno Setup supports this via `SignTool` in the `[Setup]`
  section (`SignTool=...`), not configured here since it needs a real
  certificate to test against.
- **`sideload.bat` assumes the phone allows "Install unknown apps"**
  from ADB. On stock Android this is on by default for ADB installs
  specifically, but some carrier/OEM builds restrict it further — the
  batch script's own error message points this out if `adb install`
  fails for that reason.
- **This installer doesn't auto-update the phone's app.** Re-running
  the Start Menu shortcut with a newer APK dropped in (recompile the
  installer with the new APK) reinstalls over the old version
  (`adb install -r` = reinstall, keeps app data and the person's
  saved mode choice) — there's no in-app or background update check.

## Superseded

This replaces the earlier `safe-links-reseller-windows-installer`
(built for the old Reseller-only app). If that one's already
distributed to anyone, it'll keep working — this is just the sideload
path for the new unified app.
