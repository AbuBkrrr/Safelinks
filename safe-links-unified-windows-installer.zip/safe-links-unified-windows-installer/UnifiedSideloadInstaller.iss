; SAFE_Links — Sideload Installer
; ---------------------------------------------------------------
; Compile this with Inno Setup Compiler (https://jrsoftware.org/isinfo.php)
; on a Windows machine. See README.md in this same folder for what
; needs to be dropped in before compiling (platform-tools + the APK) —
; this script will fail to compile until those are present.
; ---------------------------------------------------------------

#define MyAppName "SAFE_Links Sideloader"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "SAFE_Links"

[Setup]
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\SAFE_Links Sideloader
DefaultGroupName=SAFE_Links Sideloader
DisableProgramGroupPage=yes
OutputBaseFilename=SAFELinksSideloadSetup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible
; No code signing configured — expect a SmartScreen warning on first
; run until you sign this with a real certificate. See README.md.

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Files]
; --- ADB platform-tools: download from Google, drop the files here ---
; https://developer.android.com/tools/releases/platform-tools
Source: "platform-tools\adb.exe"; DestDir: "{app}\platform-tools"; Flags: ignoreversion
Source: "platform-tools\AdbWinApi.dll"; DestDir: "{app}\platform-tools"; Flags: ignoreversion skipifsourcedoesntexist
Source: "platform-tools\AdbWinUsbApi.dll"; DestDir: "{app}\platform-tools"; Flags: ignoreversion skipifsourcedoesntexist

; --- The app itself: build via Android Studio (Build > Build APK(s)),
; rename the output here to match ---
Source: "app-release.apk"; DestDir: "{app}"; DestName: "SAFE_Links.apk"; Flags: ignoreversion

Source: "sideload.bat"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Install SAFE_Links to phone"; Filename: "{app}\sideload.bat"; WorkingDir: "{app}"
Name: "{group}\Uninstall SAFE_Links Sideloader"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\sideload.bat"; Description: "Install the app to a connected Android phone now"; Flags: postinstall shellexec skipifsilent

[UninstallRun]
; Stop any adb.exe server process this installer started, so it
; doesn't linger after uninstall.
Filename: "{app}\platform-tools\adb.exe"; Parameters: "kill-server"; Flags: skipifdoesntexist runhidden; RunOnceId: "KillAdbServer"
