@echo off
setlocal enabledelayedexpansion
set "HERE=%~dp0"
set "ADB=%HERE%platform-tools\adb.exe"
set "APK=%HERE%SAFE_Links.apk"

echo ============================================
echo  SAFE_Links - Install to phone
echo ============================================
echo.

if not exist "%ADB%" (
    echo ERROR: adb.exe not found at:
    echo   %ADB%
    echo This installer was built without the Android platform-tools bundled in.
    echo See this installer's README.md for how to fix that.
    echo.
    pause
    goto :eof
)

if not exist "%APK%" (
    echo ERROR: SAFE_Links.apk not found at:
    echo   %APK%
    echo This installer was built without the app APK bundled in.
    echo See this installer's README.md for how to fix that.
    echo.
    pause
    goto :eof
)

echo Before continuing:
echo   1. Plug your Android phone into this PC with a USB cable.
echo   2. On the phone: Settings -^> About phone -^> tap "Build number" 7 times
echo      (this unlocks Developer options).
echo   3. Settings -^> Developer options -^> turn on "USB debugging".
echo   4. Unlock the phone's screen and keep it unlocked.
echo.
pause

echo.
echo Starting ADB and checking for your phone...
"%ADB%" start-server
echo.
"%ADB%" devices
echo.
echo Look at the list above, under "List of devices attached":
echo   - Your phone should show as "device"  (not "unauthorized" or "offline").
echo   - If it shows "unauthorized", check your phone's screen for an
echo     "Allow USB debugging?" prompt and tap Allow, then run this again.
echo   - If nothing is listed: check the cable, and that USB debugging is on.
echo.
echo Once your phone shows "device" above, press any key to install the app.
pause

echo.
echo Installing SAFE_Links...
"%ADB%" install -r "%APK%"

echo.
if %ERRORLEVEL% EQU 0 (
    echo Done. Check your phone's app drawer for "SAFE_Links".
) else (
    echo Install did not complete - see the error above.
    echo Common causes:
    echo   - Phone storage is full
    echo   - "Install via USB" / "Install unknown apps" is blocked for this
    echo     source in the phone's Developer options
    echo   - The phone went to sleep mid-install - unlock it and try again
)
echo.
pause
endlocal
