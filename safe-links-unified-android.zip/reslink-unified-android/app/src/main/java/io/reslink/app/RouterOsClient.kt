package io.reslink.app

import java.io.OutputStream
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager
import android.util.Base64

/**
 * RouterOS ships its REST API (www-ssl) with a self-signed cert by
 * default - there's no CA for a LAN device to chain to, so the
 * platform's normal cert validation can't apply here. The alternative
 * to "just disable cert checking" is trust-on-first-use (TOFU): the
 * FIRST connection in a pairing session records the leaf cert's
 * SHA-256 fingerprint and shows it to the reseller for a sanity check
 * ("does this match the sticker on your router?"); EVERY connection
 * after that, within the same session, must present that exact same
 * fingerprint or the request fails closed with CertMismatch.
 *
 * This does not protect the very first connection against an
 * on-path attacker (nothing purely local-network-based fully can,
 * without an out-of-band fingerprint to compare against - which is
 * exactly what showing the fingerprint to the human is for). What it
 * does protect against is a cert swap partway through a session, and
 * it gives the reseller a real signal to check rather than a fully
 * silent "trust everything" client.
 */
class RouterOsClient(private val gatewayIp: String) {

    sealed class RouterOsResult {
        data class Success(val body: String) : RouterOsResult()
        data class HttpError(val code: Int, val body: String) : RouterOsResult()
        data class CertMismatch(val seenFingerprint: String, val expectedFingerprint: String) : RouterOsResult()
        data class NetworkError(val message: String) : RouterOsResult()
    }

    /** Fingerprint pinned after the first successful connection this session. Null until then. */
    var pinnedFingerprint: String? = null
        private set

    private fun sslContextFor(expectedFingerprint: String?): SSLContext {
        var observed: String? = null

        val trustManager = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit

            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                val leaf = chain?.firstOrNull()
                    ?: throw CertificateException("No certificate presented by $gatewayIp")
                val fp = sha256Fingerprint(leaf)
                observed = fp
                if (expectedFingerprint != null && fp != expectedFingerprint) {
                    // Fail closed: don't complete the handshake on mismatch.
                    throw CertificateException("Certificate fingerprint changed since first probe")
                }
            }

            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }

        return SSLContext.getInstance("TLS").apply {
            init(null, arrayOf(trustManager), SecureRandom())
        }.also {
            // Stash the observed fingerprint where callers can retrieve it
            // after a successful handshake via lastObservedFingerprint().
            lastObserved = { observed }
        }
    }

    private var lastObserved: (() -> String?)? = null

    private fun sha256Fingerprint(cert: X509Certificate): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(cert.encoded)
        return digest.joinToString(":") { "%02X".format(it) }
    }

    private fun connection(path: String, expectedFingerprint: String?): HttpsURLConnection {
        val url = URL("https://$gatewayIp$path")
        val conn = url.openConnection() as HttpsURLConnection
        conn.sslSocketFactory = sslContextFor(expectedFingerprint).socketFactory
        // Local LAN devices are addressed by IP, not a hostname a cert
        // could ever legitimately match - the fingerprint check above is
        // the real trust boundary here, not hostname verification.
        conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
        conn.connectTimeout = 4000
        conn.readTimeout = 8000
        return conn
    }

    /**
     * First call of a pairing session. Confirms something is listening
     * and speaking RouterOS's REST API, and captures the cert
     * fingerprint for the reseller to confirm before we do anything
     * that changes router configuration.
     */
    fun probe(adminUser: String, adminPass: String): RouterOsResult {
        return try {
            val conn = connection("/rest/system/resource", expectedFingerprint = null)
            conn.requestMethod = "GET"
            conn.setRequestProperty("Authorization", basicAuth(adminUser, adminPass))
            val code = conn.responseCode
            val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText().orEmpty()
            val fp = lastObserved?.invoke()
            if (fp != null) pinnedFingerprint = fp

            when {
                code !in 200..299 -> RouterOsResult.HttpError(code, body)
                !body.contains("\"board-name\"") && !body.contains("\"version\"") ->
                    RouterOsResult.HttpError(code, "Response didn't look like RouterOS: $body")
                else -> RouterOsResult.Success(body)
            }
        } catch (e: CertificateException) {
            RouterOsResult.NetworkError("TLS handshake failed: ${e.message}")
        } catch (e: Exception) {
            RouterOsResult.NetworkError(e.message ?: e.toString())
        }
    }

    /**
     * Runs a script via POST /rest/execute. Must be called after
     * probe() succeeded and the reseller confirmed the fingerprint -
     * pass that confirmed fingerprint in as expectedFingerprint so this
     * call fails closed if the cert changed in between.
     */
    fun execute(script: String, adminUser: String, adminPass: String, expectedFingerprint: String): RouterOsResult {
        return try {
            val conn = connection("/rest/execute", expectedFingerprint)
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Authorization", basicAuth(adminUser, adminPass))
            conn.setRequestProperty("Content-Type", "application/json")

            val payload = """{"script": ${jsonString(script)}}"""
            (conn.outputStream as OutputStream).use { it.write(payload.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText().orEmpty()

            when {
                code !in 200..299 -> RouterOsResult.HttpError(code, body)
                else -> RouterOsResult.Success(body)
            }
        } catch (e: CertificateException) {
            RouterOsResult.CertMismatch(lastObserved?.invoke().orEmpty(), expectedFingerprint)
        } catch (e: Exception) {
            RouterOsResult.NetworkError(e.message ?: e.toString())
        }
    }

    private fun basicAuth(user: String, pass: String): String {
        val token = Base64.encodeToString("$user:$pass".toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        return "Basic $token"
    }

    private fun jsonString(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c.code < 0x20) sb.append("\\u%04x".format(c.code)) else sb.append(c)
            }
        }
        sb.append("\"")
        return sb.toString()
    }
}
