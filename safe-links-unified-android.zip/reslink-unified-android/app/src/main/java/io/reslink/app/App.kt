package io.reslink.app

import android.app.Application

class ReslinkApp : Application()
