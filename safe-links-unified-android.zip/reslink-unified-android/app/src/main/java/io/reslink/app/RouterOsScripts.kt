package io.reslink.app

/**
 * Builds the exact RouterOS script text that gets POSTed to
 * /rest/execute on the router. This is a direct adaptation of
 * reslink-backend/router-scripts/reslink-agent.rsc - same two pieces
 * (register once, checkin recurring via scheduler), same wire
 * protocol (plain `KEY value` lines, not JSON - see agent.js), same
 * credential-persistence-to-file approach so it survives a reboot.
 *
 * IMPORTANT: reslink-agent.rsc's own header says it was "written
 * against documented RouterOS 7 scripting syntax... has NOT been run
 * against a physical router." That caveat applies here too - this
 * generator produces the same script text, so it inherits the same
 * validation status. Test against a spare device or a Cloud Hosted
 * Router before relying on this in the field.
 */
object RouterOsScripts {

    // Assumes frontend and backend share an origin (nginx proxying
    // /api/* to the backend alongside the served frontend - see
    // frontend/nginx.conf and docker-compose.yml, which is how this
    // project is set up by default). If a deployment ever splits these
    // onto separate domains, apiBaseUrl needs to become its own
    // BuildConfig field rather than reusing APP_BASE_URL.

    private val PAIRING_CODE_RE = Regex("^[A-Z0-9]{4,10}$")

    class InvalidPairingCode(code: String) :
        IllegalArgumentException("Pairing code has an unexpected format: $code")

    /**
     * Step 1 (run once, idempotent): installs the recurring checkin
     * script + a disabled scheduler entry. Safe to re-run - it removes
     * any prior reslink-checkin script/scheduler first, same as the
     * source .rsc file does.
     */
    fun buildInstallCheckinScript(apiBaseUrl: String): String {
        val api = apiBaseUrl.trimEnd('/')
        return """
            :global resLinkApiUrl "$api"
            :global resLinkCredFile "reslink-credentials.txt"

            /system script
            :if ([:len [/system script find name="reslink-checkin"]] > 0) do={ remove [find name="reslink-checkin"] }
            add name="reslink-checkin" source={
              :global resLinkApiUrl
              :global resLinkCredFile

              :if ([:len [/file find name=${'$'}resLinkCredFile]] = 0) do={
                :log warning "reslink-checkin: not paired yet"
                :error "reslink-checkin: no credentials file"
              }

              :local credContents [/file get [find name=${'$'}resLinkCredFile] contents]
              :local nl1 [:find ${'$'}credContents "\n"]
              :local routerId [:pick ${'$'}credContents 0 ${'$'}nl1]
              :local rest [:pick ${'$'}credContents (${'$'}nl1 + 1) [:len ${'$'}credContents]]
              :local nl2 [:find ${'$'}rest "\n"]
              :local apiKey [:pick ${'$'}rest 0 ${'$'}nl2]

              :local postData ("router_id=" . ${'$'}routerId . "&api_key=" . ${'$'}apiKey)
              :local result ""
              :do {
                :local fetchResult [/tool fetch url=(${'$'}resLinkApiUrl . "/api/agent/checkin") http-method=post http-data=${'$'}postData as-value output=user]
                :set result (${'$'}fetchResult->"data")
              } on-error={
                :log warning "reslink-checkin: could not reach Reslink this cycle"
                :error "reslink-checkin: fetch failed"
              }

              :if ([:find ${'$'}result "STATUS OK"] = nil) do={
                :log warning ("reslink-checkin: server rejected check-in - " . ${'$'}result)
                :error "reslink-checkin: bad response"
              }

              :local pos 0
              :while (${'$'}pos < [:len ${'$'}result]) do={
                :local nl [:find ${'$'}result "\n" ${'$'}pos]
                :if (${'$'}nl = nil) do={ :set nl [:len ${'$'}result] }
                :local line [:pick ${'$'}result ${'$'}pos ${'$'}nl]
                :set pos (${'$'}nl + 1)
                :if ([:pick ${'$'}line 0 4] = "CMD ") do={
                  :local rest2 [:pick ${'$'}line 4 [:len ${'$'}line]]
                  :local fields {}
                  :local fpos 0
                  :while (${'$'}fpos <= [:len ${'$'}rest2]) do={
                    :local sp [:find ${'$'}rest2 " " ${'$'}fpos]
                    :if (${'$'}sp = nil) do={ :set sp [:len ${'$'}rest2] }
                    :set fields (${'$'}fields, [:pick ${'$'}rest2 ${'$'}fpos ${'$'}sp])
                    :set fpos (${'$'}sp + 1)
                  }
                  :local cmdId (${'$'}fields->0)
                  :local cmdType (${'$'}fields->1)
                  :local cmdUser (${'$'}fields->2)
                  :local cmdPass (${'$'}fields->3)
                  :local cmdBandwidth (${'$'}fields->5)

                  :local execStatus "executed"
                  :local execDetail ""
                  :do {
                    :if (${'$'}cmdType = "create_user") do={
                      :local rateLimit (${'$'}cmdBandwidth . "M/" . ${'$'}cmdBandwidth . "M")
                      :if ([:len [/ip hotspot user find name=${'$'}cmdUser]] > 0) do={
                        /ip hotspot user set [find name=${'$'}cmdUser] password=${'$'}cmdPass rate-limit=${'$'}rateLimit
                      } else={
                        /ip hotspot user add name=${'$'}cmdUser password=${'$'}cmdPass rate-limit=${'$'}rateLimit
                      }
                    } else={ :if (${'$'}cmdType = "enable_user") do={
                      /ip hotspot user enable [find name=${'$'}cmdUser]
                    } else={ :if (${'$'}cmdType = "disable_user") do={
                      /ip hotspot user disable [find name=${'$'}cmdUser]
                    } else={ :if (${'$'}cmdType = "delete_user") do={
                      /ip hotspot user remove [find name=${'$'}cmdUser]
                    } else={
                      :set execStatus "failed"
                      :set execDetail ("unknown command type: " . ${'$'}cmdType)
                    }}}}
                  } on-error={
                    :set execStatus "failed"
                    :set execDetail ("RouterOS command threw an error executing " . ${'$'}cmdType)
                  }

                  :local ackData ("router_id=" . ${'$'}routerId . "&api_key=" . ${'$'}apiKey . "&status=" . ${'$'}execStatus . "&detail=" . ${'$'}execDetail)
                  :do {
                    /tool fetch url=(${'$'}resLinkApiUrl . "/api/agent/commands/" . ${'$'}cmdId . "/ack") http-method=post http-data=${'$'}ackData output=none
                  } on-error={
                    :log warning ("reslink-checkin: could not ack command " . ${'$'}cmdId)
                  }
                }
              }
            }

            /system scheduler
            :if ([:len [/system scheduler find name="reslink-checkin"]] > 0) do={ remove [find name="reslink-checkin"] }
            add name="reslink-checkin" interval=30s on-event="/system script run reslink-checkin" disabled=yes
            :put "checkin script installed"
        """.trimIndent()
    }

    /**
     * Step 2 (run once): the equivalent of a human running
     * `/system script run reslink-register` after pasting in the
     * pairing code by hand - except here the code is baked in by the
     * app, and this runs inline via /rest/execute rather than being
     * saved as a named script (no need to persist something that only
     * ever runs once).
     */
    fun buildRegisterScript(pairingCode: String, apiBaseUrl: String): String {
        if (!PAIRING_CODE_RE.matches(pairingCode)) throw InvalidPairingCode(pairingCode)
        val api = apiBaseUrl.trimEnd('/')
        return """
            :global resLinkApiUrl "$api"
            :global resLinkCredFile "reslink-credentials.txt"
            :local pairingCode "$pairingCode"

            :local routerIdentity [/system identity get name]
            :local routerModel [/system routerboard get model]
            :local routerFirmware ("RouterOS " . [/system package get [find name="routeros"] version])

            :local postData ("code=" . ${'$'}pairingCode . "&model=" . ${'$'}routerModel . "&firmware=" . ${'$'}routerFirmware . "&identity=" . ${'$'}routerIdentity)

            :local result ""
            :do {
              :local fetchResult [/tool fetch url=(${'$'}resLinkApiUrl . "/api/agent/register") http-method=post http-data=${'$'}postData as-value output=user]
              :set result (${'$'}fetchResult->"data")
            } on-error={
              :log error "reslink-register: could not reach Reslink"
              :error "reslink-register: fetch failed"
            }

            :if ([:find ${'$'}result "STATUS OK"] = nil) do={
              :log error ("reslink-register: registration failed - " . ${'$'}result)
              :error "reslink-register: server rejected registration"
            }

            :local routerId ""
            :local apiKey ""
            :local pos 0
            :while (${'$'}pos < [:len ${'$'}result]) do={
              :local nl [:find ${'$'}result "\n" ${'$'}pos]
              :if (${'$'}nl = nil) do={ :set nl [:len ${'$'}result] }
              :local line [:pick ${'$'}result ${'$'}pos ${'$'}nl]
              :if ([:pick ${'$'}line 0 10] = "ROUTER_ID ") do={ :set routerId [:pick ${'$'}line 10 [:len ${'$'}line]] }
              :if ([:pick ${'$'}line 0 8] = "API_KEY ") do={ :set apiKey [:pick ${'$'}line 8 [:len ${'$'}line]] }
              :set pos (${'$'}nl + 1)
            }

            :if (${'$'}routerId = "" or ${'$'}apiKey = "") do={
              :log error "reslink-register: could not parse ROUTER_ID/API_KEY"
              :error "reslink-register: parse failure"
            }

            :local credContents (${'$'}routerId . "\n" . ${'$'}apiKey . "\n")
            :if ([:len [/file find name=${'$'}resLinkCredFile]] > 0) do={ /file remove [find name=${'$'}resLinkCredFile] }
            /file add name=${'$'}resLinkCredFile contents=${'$'}credContents

            /system scheduler enable [find name="reslink-checkin"]
            :put ("ROUTER_ID=" . ${'$'}routerId)
        """.trimIndent()
    }
}
