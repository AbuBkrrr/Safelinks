package io.reslink.app

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Exposed to the WebView as `window.ReslinkNative`. Only reachable
 * because ResellerApp.jsx feature-detects it (`typeof
 * window.ReslinkNative?.probe === "function"`) - it does nothing
 * unless the web UI explicitly calls it from the "Pair automatically"
 * button on the Routers tab.
 *
 * Two-call protocol, deliberately not a single do-everything call:
 *
 *   1. probe(adminUser, adminPass)
 *        -> window.onReslinkProbeResult({ ok, fingerprint, gatewayIp, error })
 *      Confirms there's a RouterOS device at the LAN gateway and
 *      captures its cert fingerprint. Changes nothing on the router.
 *
 *   2. pairWithConfirmedFingerprint(pairingCode, adminUser, adminPass, confirmedFingerprint)
 *        -> window.onReslinkPairResult({ ok, routerId, error })
 *      Only proceeds if the router's cert still matches
 *      confirmedFingerprint at connection time - this is what the web
 *      UI shows the reseller between steps 1 and 2 ("does this match
 *      the sticker on your router?"), so step 2 is the one that
 *      actually pushes configuration.
 *
 * This class intentionally does NOT persist router admin credentials
 * anywhere - they're passed in from the WebView's own form fields at
 * call time and held only in memory for the duration of these two
 * calls. Nothing here calls addJavascriptInterface for arbitrary
 * pages - see MainActivity, which only attaches this to WebViews
 * navigating within APP_BASE_URL's origin.
 */
class RouterLanBridge(private val context: Context, private val webView: WebView) {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    // Keyed by gatewayIp so a probe result can't accidentally be reused
    // against a different router than the one it was captured from.
    private var activeClient: RouterOsClient? = null
    private var activeGatewayIp: String? = null

    @JavascriptInterface
    fun probe(adminUser: String, adminPass: String) {
        executor.execute {
            val gateway = GatewayLocator.locate(context)
            if (gateway == null) {
                callback("onReslinkProbeResult", errorJson("Could not determine the LAN gateway. Are you connected to WiFi?"))
                return@execute
            }
            if (!gateway.isWifi) {
                callback("onReslinkProbeResult", errorJson("Not connected to WiFi - automatic pairing needs to be on the same network as the router."))
                return@execute
            }

            val client = RouterOsClient(gateway.gatewayIp)
            when (val result = client.probe(adminUser, adminPass)) {
                is RouterOsClient.RouterOsResult.Success -> {
                    activeClient = client
                    activeGatewayIp = gateway.gatewayIp
                    callback("onReslinkProbeResult", JSONObject().apply {
                        put("ok", true)
                        put("gatewayIp", gateway.gatewayIp)
                        put("fingerprint", client.pinnedFingerprint)
                    })
                }
                is RouterOsClient.RouterOsResult.HttpError -> callback(
                    "onReslinkProbeResult",
                    errorJson("Router rejected the request (HTTP ${result.code}). Check the admin username/password.")
                )
                is RouterOsClient.RouterOsResult.NetworkError -> callback(
                    "onReslinkProbeResult",
                    errorJson("Couldn't reach ${gateway.gatewayIp}: ${result.message}. Is the REST API (www-ssl) enabled on this router?")
                )
                is RouterOsClient.RouterOsResult.CertMismatch -> callback(
                    "onReslinkProbeResult",
                    errorJson("Unexpected certificate state during probe.")
                )
            }
        }
    }

    @JavascriptInterface
    fun pairWithConfirmedFingerprint(
        pairingCode: String,
        adminUser: String,
        adminPass: String,
        confirmedFingerprint: String
    ) {
        executor.execute {
            val client = activeClient
            val gatewayIp = activeGatewayIp
            if (client == null || gatewayIp == null) {
                callback("onReslinkPairResult", errorJson("No active probe session - call probe() first."))
                return@execute
            }
            if (client.pinnedFingerprint != confirmedFingerprint) {
                callback("onReslinkPairResult", errorJson("Fingerprint you confirmed doesn't match what was probed - aborting rather than risk pairing the wrong device."))
                return@execute
            }

            val installScript = RouterOsScripts.buildInstallCheckinScript(apiBaseUrl = BuildConfig.APP_BASE_URL)
            val installResult = client.execute(installScript, adminUser, adminPass, confirmedFingerprint)
            if (installResult !is RouterOsClient.RouterOsResult.Success) {
                callback("onReslinkPairResult", errorJson("Could not install the check-in script: ${describe(installResult)}"))
                return@execute
            }

            val registerScript = try {
                RouterOsScripts.buildRegisterScript(pairingCode, apiBaseUrl = BuildConfig.APP_BASE_URL)
            } catch (e: RouterOsScripts.InvalidPairingCode) {
                callback("onReslinkPairResult", errorJson(e.message ?: "Invalid pairing code"))
                return@execute
            }

            val registerResult = client.execute(registerScript, adminUser, adminPass, confirmedFingerprint)
            when (registerResult) {
                is RouterOsClient.RouterOsResult.Success -> {
                    val routerId = Regex("ROUTER_ID=(\\S+)").find(registerResult.body)?.groupValues?.get(1)
                    callback("onReslinkPairResult", JSONObject().apply {
                        put("ok", true)
                        put("routerId", routerId)
                    })
                    // One-shot: clear the session so a stray extra call
                    // can't silently reuse stale credentials/session state.
                    activeClient = null
                    activeGatewayIp = null
                }
                else -> callback("onReslinkPairResult", errorJson("Registration failed: ${describe(registerResult)}"))
            }
        }
    }

    private fun describe(result: RouterOsClient.RouterOsResult): String = when (result) {
        is RouterOsClient.RouterOsResult.Success -> "ok"
        is RouterOsClient.RouterOsResult.HttpError -> "HTTP ${result.code}: ${result.body.take(200)}"
        is RouterOsClient.RouterOsResult.NetworkError -> result.message
        is RouterOsClient.RouterOsResult.CertMismatch -> "router's certificate changed since it was confirmed - aborted"
    }

    private fun errorJson(message: String) = JSONObject().apply {
        put("ok", false)
        put("error", message)
    }

    private fun callback(jsFunctionName: String, payload: JSONObject) {
        mainHandler.post {
            webView.evaluateJavascript(
                "window.$jsFunctionName && window.$jsFunctionName(${payload});",
                null
            )
        }
    }
}
