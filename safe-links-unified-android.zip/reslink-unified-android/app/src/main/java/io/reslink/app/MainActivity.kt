package io.reslink.app

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import io.reslink.app.databinding.ActivityMainBinding

/**
 * Single native shell covering everything the SAFE_Links web app does,
 * matching how the web app itself actually works: Reseller and Super
 * Admin already share one login screen at the site root (BuildConfig.
 * APP_BASE_URL) - which dashboard renders is decided by which account
 * someone logs into, not by a URL. The one genuinely separate flow is
 * the router installer at APP_BASE_URL + "install" - typically a field
 * technician who has no reseller account at all.
 *
 * Rather than pretend those are different apps (the previous design
 * here), this Activity shows a small native picker on first launch -
 * "I'm a Reseller / Admin" vs "I'm pairing a router" - remembers the
 * choice, and loads the matching URL. "Switch mode" in the overflow
 * menu re-shows the picker without losing the logged-in session,
 * since both URLs are same-origin and localStorage doesn't care which
 * path loaded it.
 *
 * Also exposes window.ReslinkNative (see RouterLanBridge) to the
 * WebView regardless of mode - the LAN-pairing UI it powers is the
 * same PairingFlow component embedded both in the Reseller dashboard's
 * Routers tab AND the standalone /install page, so both modes benefit
 * from it. This is the ONLY JavascriptInterface in this app, and it's
 * only ever reachable on pages served from APP_BASE_URL's origin -
 * shouldOverrideUrlLoading below sends every other origin out to the
 * system browser instead of loading it here.
 */
class MainActivity : AppCompatActivity() {

    private enum class Mode(val path: String) {
        RESELLER_ADMIN(""),
        INSTALLER("install")
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var webViewInitialized = false

    private val fileChooserLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            val callback = fileUploadCallback
            fileUploadCallback = null
            if (callback == null) return@registerForActivityResult
            val data = result.data
            val uris: Array<Uri>? = when {
                result.resultCode != RESULT_OK || data == null -> null
                data.clipData != null -> {
                    val clip = data.clipData!!
                    Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                }
                data.data != null -> arrayOf(data.data!!)
                else -> null
            }
            callback.onReceiveValue(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = getSharedPreferences("reslink_prefs", MODE_PRIVATE)

        setupWebView()
        setupSwipeRefresh()
        setupBackNavigation()
        setupModePicker()
        binding.retryButton.setOnClickListener { loadStartUrl() }

        val savedMode = readSavedMode()
        if (savedMode != null) {
            showWebViewContainer()
            if (savedInstanceState != null) {
                binding.webView.restoreState(savedInstanceState)
                webViewInitialized = true
            } else {
                loadUrlForMode(savedMode)
            }
        } else {
            showModePicker()
        }
    }

    private fun setupModePicker() {
        binding.buttonResellerAdmin.setOnClickListener { chooseMode(Mode.RESELLER_ADMIN) }
        binding.buttonInstaller.setOnClickListener { chooseMode(Mode.INSTALLER) }
    }

    private fun chooseMode(mode: Mode) {
        prefs.edit().putString(KEY_MODE, mode.name).apply()
        showWebViewContainer()
        loadUrlForMode(mode)
    }

    private fun readSavedMode(): Mode? {
        val name = prefs.getString(KEY_MODE, null) ?: return null
        return runCatching { Mode.valueOf(name) }.getOrNull()
    }

    private fun loadUrlForMode(mode: Mode) {
        if (!isOnline()) {
            showOffline()
            return
        }
        showContent()
        val base = BuildConfig.APP_BASE_URL.trimEnd('/')
        val url = if (mode.path.isEmpty()) "$base/" else "$base/${mode.path}"
        binding.webView.loadUrl(url)
        webViewInitialized = true
    }

    /** Used by the offline screen's Retry button - reloads whatever mode is currently active. */
    private fun loadStartUrl() {
        val mode = readSavedMode() ?: return // picker is showing; nothing to retry yet
        loadUrlForMode(mode)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_switch_mode) {
            showModePicker()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showModePicker() {
        binding.modePicker.visibility = View.VISIBLE
        binding.swipeRefresh.visibility = View.GONE
        binding.offlineView.visibility = View.GONE
        binding.progressBar.visibility = View.GONE
    }

    private fun showWebViewContainer() {
        binding.modePicker.visibility = View.GONE
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true // required: session token lives in localStorage
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.setSupportMultipleWindows(false)
        settings.mediaPlaybackRequiresUserGesture = true
        settings.userAgentString = settings.userAgentString + " ReslinkApp/${BuildConfig.VERSION_NAME}"

        // LAN router pairing bridge - see RouterLanBridge's own doc
        // comment for the security model (TOFU cert pinning,
        // credentials never persisted, fails closed on any mismatch).
        // Attached unconditionally: useful in both modes (see class doc).
        webView.addJavascriptInterface(RouterLanBridge(this, webView), "ReslinkNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url
                val host = url.host ?: ""
                val baseHost = BuildConfig.APP_BASE_URL.toUri().host ?: ""
                // Keep same-origin navigation inside the app (this is how
                // moving between Reseller/Admin views and the embedded
                // installer flow works - it's all client-side state on
                // one origin); hand off anything else (support links,
                // mailto:, tel:, docs) to the system so it opens in the
                // user's normal browser or matching app.
                return if (host == baseHost) {
                    false
                } else {
                    openExternally(url)
                    true
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                binding.swipeRefresh.isRefreshing = false
                binding.progressBar.visibility = View.GONE
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) {
                    showOffline()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                binding.progressBar.progress = newProgress
                binding.progressBar.visibility =
                    if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            // Lets file-upload fields (payment-proof screenshots, support
            // ticket attachments, etc.) open the native file picker.
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                val intent = fileChooserParams.createIntent()
                return try {
                    fileChooserLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    fileUploadCallback = null
                    false
                }
            }

            // Only relevant if a future version adds camera-based QR
            // pairing; harmless no-op otherwise. Denies by default -
            // grant explicitly if/when that feature ships.
            override fun onPermissionRequest(request: PermissionRequest) {
                request.deny()
            }
        }
    }

    private fun openExternally(url: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, url))
        } catch (_: Exception) {
            // No app can handle it - ignore rather than crash.
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            if (isOnline()) {
                binding.webView.reload()
            } else {
                binding.swipeRefresh.isRefreshing = false
                showOffline()
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    when {
                        binding.modePicker.visibility == View.VISIBLE && readSavedMode() != null -> {
                            // Reached the picker via "Switch mode" with a
                            // mode already chosen before - back cancels
                            // back to whatever was already loaded rather
                            // than exiting the app.
                            showWebViewContainer()
                        }
                        webViewInitialized && binding.webView.canGoBack() -> binding.webView.goBack()
                        else -> {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                        }
                    }
                }
            }
        )
    }

    private fun showOffline() {
        binding.offlineView.visibility = View.VISIBLE
        binding.swipeRefresh.visibility = View.GONE
    }

    private fun showContent() {
        binding.offlineView.visibility = View.GONE
        binding.swipeRefresh.visibility = View.VISIBLE
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network: Network = cm.activeNetwork ?: return false
        val caps: NetworkCapabilities = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (webViewInitialized) {
            binding.webView.saveState(outState)
        }
    }

    override fun onDestroy() {
        binding.webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val KEY_MODE = "mode"
    }
}
