package io.reslink.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.Inet4Address

/**
 * Finds the current WiFi network's default gateway IP.
 *
 * Deliberately uses ConnectivityManager/LinkProperties rather than
 * WifiManager.getConnectionInfo() - reading the gateway/route table
 * doesn't require ACCESS_FINE_LOCATION, whereas reading the SSID/BSSID
 * does. We never need the SSID for this feature, so we never trigger
 * that permission requirement.
 */
object GatewayLocator {

    data class Result(val gatewayIp: String, val isWifi: Boolean)

    fun locate(context: Context): Result? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return null
        val network = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(network) ?: return null
        val isWifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)

        val linkProperties = cm.getLinkProperties(network) ?: return null
        val gateway = linkProperties.routes
            .firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway
            ?: return null

        return Result(gatewayIp = gateway.hostAddress ?: return null, isWifi = isWifi)
    }
}
