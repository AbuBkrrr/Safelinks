plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "io.reslink.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "io.reslink.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        // ---------------------------------------------------------------
        // THE ONE SETTING YOU CHANGE PER DEPLOYMENT.
        // The site's origin (no path). MainActivity derives both mode
        // URLs from this: the Reseller/Admin picker loads APP_BASE_URL
        // itself, and "pairing a router" loads APP_BASE_URL + "install".
        // Override per build type below.
        // ---------------------------------------------------------------
        buildConfigField("String", "APP_BASE_URL", "\"https://app.example.com/\"")
    }

    buildFeatures {
        buildConfig = true
        viewBinding = true
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            // Emulator's alias for the host machine's localhost, so
            // `npm run dev` on your laptop is reachable from the emulator
            // without editing anything. Swap for your LAN IP on a real
            // device, or point straight at a deployed staging URL.
            buildConfigField("String", "APP_BASE_URL", "\"http://10.0.2.2:5173/\"")
            applicationIdSuffix = ".debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            buildConfigField("String", "APP_BASE_URL", "\"https://app.example.com/\"")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
}
