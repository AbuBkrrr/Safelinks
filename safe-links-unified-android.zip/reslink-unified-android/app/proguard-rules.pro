# Add project specific ProGuard rules here.
# Keeps the @JavascriptInterface methods on RouterLanBridge (the
# window.ReslinkNative bridge) reachable from the WebView in release
# builds - R8 would otherwise be free to rename/strip them.
-keepclassmembers class io.reslink.app.** {
    @android.webkit.JavascriptInterface <methods>;
}
