/**
 * WEB-SIDE COMPANION TO THIS ANDROID PROJECT'S RouterLanBridge.
 *
 * This file is NOT part of the Android build - it's a snippet meant
 * for frontend/src/InstallerWizard.jsx in the main SAFE_Links repo.
 * The native bridge is unreachable without this (or something like
 * it) calling window.ReslinkNative - it's dead code on its own.
 *
 * ---------------------------------------------------------------
 * HOW TO APPLY
 * ---------------------------------------------------------------
 * 1. In frontend/src/InstallerWizard.jsx, paste the <LanAutoPair />
 *    component below anywhere after PairingFlow's closing brace.
 * 2. Inside PairingFlow's `status === "pending"` block (the one that
 *    shows the 6-character code), add this line right after the
 *    "Waiting for the router to check in…" div:
 *
 *      <LanAutoPair code={code} onPaired={() => checkStatus(code)} />
 *
 *    That's it — LanAutoPair reuses the *same* pairing code already
 *    on screen. It doesn't call POST /api/reseller/pairing-codes
 *    itself, and onPaired just triggers the existing poll-once-more
 *    so the UI flips to "used" the moment the backend sees the
 *    router's own POST /api/agent/register come in (which still
 *    happens exactly as before - this only automates who/what makes
 *    that call, not the backend's understanding of it).
 *
 * WHY THIS IS SEPARATE FROM THE EXISTING "Pair automatically
 * (MikroTik)" LABEL ON THE MODE PICKER: that label already exists in
 * this file and means something different — it's about the ROUTER
 * self-reporting its model/firmware once a human types the code in.
 * This component removes the "human types the code in" step entirely,
 * for MikroTik routers reachable on the same LAN as the phone. It only
 * renders at all when window.ReslinkNative is present (i.e. only
 * inside the SAFE_Links app), so it changes nothing for the
 * standalone Installer app, the PWA, or desktop browsers.
 */

import React, { useState } from "react";
import { Wifi, Loader2, CheckCircle2 } from "lucide-react";
import { T, Btn, Field, inputStyle } from "./ui.jsx";

function LanAutoPair({ code, onPaired }) {
  // idle -> credentials -> probing -> confirm -> pairing -> done | error
  const [stage, setStage] = useState("idle");
  const [adminUser, setAdminUser] = useState("admin");
  const [adminPass, setAdminPass] = useState("");
  const [fingerprint, setFingerprint] = useState(null);
  const [gatewayIp, setGatewayIp] = useState(null);
  const [error, setError] = useState(null);

  if (typeof window === "undefined" || !window.ReslinkNative?.probe) {
    return null; // not running inside the SAFE_Links app
  }

  function startProbe() {
    setError(null);
    setStage("probing");

    window.onReslinkProbeResult = (result) => {
      if (!result.ok) {
        setError(result.error || "Could not reach the router.");
        setStage("credentials");
        return;
      }
      setFingerprint(result.fingerprint);
      setGatewayIp(result.gatewayIp);
      setStage("confirm");
    };

    window.ReslinkNative.probe(adminUser, adminPass);
  }

  function confirmAndPair() {
    setStage("pairing");
    setError(null);

    window.onReslinkPairResult = (result) => {
      if (!result.ok) {
        setError(result.error || "Pairing failed.");
        setStage("credentials");
        return;
      }
      setStage("done");
      onPaired?.();
    };

    window.ReslinkNative.pairWithConfirmedFingerprint(code, adminUser, adminPass, fingerprint);
  }

  return (
    <div style={{ marginTop: 18, paddingTop: 16, borderTop: `1px dashed ${T.border}`, textAlign: "left" }}>
      {stage === "idle" && (
        <div
          onClick={() => setStage("credentials")}
          style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", color: T.primary, fontSize: 12.5, fontWeight: 600, justifyContent: "center" }}
        >
          <Wifi size={14} /> On the same WiFi as the router? Pair automatically — no typing required
        </div>
      )}

      {stage === "credentials" && (
        <>
          <div style={{ fontSize: 12, color: T.sub, marginBottom: 10, textAlign: "center" }}>
            Enter this router's admin login. It's only used for this pairing and isn't stored.
          </div>
          <Field label="Admin username">
            <input style={inputStyle} value={adminUser} onChange={(e) => setAdminUser(e.target.value)} />
          </Field>
          <Field label="Admin password">
            <input type="password" style={inputStyle} value={adminPass} onChange={(e) => setAdminPass(e.target.value)} />
          </Field>
          {error && <div style={{ fontSize: 12, color: T.danger, marginBottom: 10 }}>{error}</div>}
          <Btn size="sm" onClick={startProbe} style={{ width: "100%", justifyContent: "center" }}>
            Find router on this network
          </Btn>
        </>
      )}

      {stage === "probing" && (
        <div style={{ textAlign: "center", fontSize: 12.5, color: T.sub, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
          <Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> Looking for a router at your gateway…
        </div>
      )}

      {stage === "confirm" && (
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 12.5, color: T.sub, marginBottom: 8 }}>
            Found a router at <span style={{ fontFamily: "monospace" }}>{gatewayIp}</span>.
            Check its certificate fingerprint matches the sticker on the device
            (or its RouterOS <code>/certificate print</code> output) before continuing:
          </div>
          <div style={{ fontFamily: "monospace", fontSize: 10.5, wordBreak: "break-all", background: T.bg, borderRadius: 8, padding: 10, marginBottom: 12 }}>
            {fingerprint}
          </div>
          {error && <div style={{ fontSize: 12, color: T.danger, marginBottom: 10 }}>{error}</div>}
          <Btn size="sm" onClick={confirmAndPair} style={{ width: "100%", justifyContent: "center" }}>
            Matches — pair this router
          </Btn>
        </div>
      )}

      {stage === "pairing" && (
        <div style={{ textAlign: "center", fontSize: 12.5, color: T.sub, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
          <Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> Configuring the router…
        </div>
      )}

      {stage === "done" && (
        <div style={{ textAlign: "center", fontSize: 12.5, color: T.success, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
          <CheckCircle2 size={14} /> Sent — waiting for the router's first check-in above.
        </div>
      )}
    </div>
  );
}

export default LanAutoPair;
