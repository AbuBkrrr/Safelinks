# SAFE_Links — unified Android app

One app, one package (`io.reslink.app`), covering everything the web
app does. This replaces the earlier three-separate-apps design
(Installer / Reseller / Super Admin) with something closer to how the
web app actually behaves.

## Why one app

The web app itself only ever had two identities, not three (see
`frontend/index.html`): Reseller and Super Admin already share one
login screen at the site root — which dashboard renders is decided by
which account logs in, not by a URL. Building three separately-branded
Android apps for that was mostly fiction. The one flow that's
genuinely different is the router installer at `/install` — usually a
field technician with no reseller account at all.

So this app shows a small **native picker on first launch**:

- **"I'm a Reseller / Admin"** → loads the site root. Whether that
  turns out to be the Reseller or Super Admin dashboard is still
  entirely up to which account they log into, same as the web app.
- **"I'm pairing a router"** → loads `/install` directly.

The choice is remembered (`SharedPreferences`), so this only shows
once. **"Switch mode"** in the overflow menu (⋮) brings it back
anytime — switching doesn't log anyone out, since both URLs are the
same origin and the session lives in `localStorage`, which doesn't
care which path loaded it.

## Opening in Android Studio

1. **Android Studio → Open**, select this `reslink-unified-android/`
   folder (the one with `settings.gradle.kts`).
2. Let it sync — `gradle/wrapper/gradle-wrapper.jar` regenerates
   automatically as long as you're online. If not, run
   `File → Sync Project with Gradle Files`.
3. **Run ▶** on an emulator or device (min SDK 24 / Android 7.0+).

## The one setting you actually need to change

`app/build.gradle.kts` → `APP_BASE_URL` — the site's origin, no path.
Both picker destinations are derived from it at runtime
(`MainActivity.loadUrlForMode`):

```kotlin
debug {
    buildConfigField("String", "APP_BASE_URL", "\"http://10.0.2.2:5173/\"")
    // preconfigured to hit `npm run dev` on your machine, via the
    // emulator's localhost alias
}
release {
    buildConfigField("String", "APP_BASE_URL", "\"https://app.example.com/\"")
    // ← replace with your real deployed domain
}
```

## Feature checklist

- ✅ Native mode picker on first launch, remembered, switchable from
  the overflow menu without losing the login session
- ✅ JS + DOM storage enabled (session token lives in `localStorage`)
- ✅ Hardware back button navigates WebView history, then the picker
  (if reached via "Switch mode"), then exits
- ✅ Pull-to-refresh
- ✅ Native file picker for any `<input type="file">` (payment-proof
  screenshots, support attachments, etc.)
- ✅ Offline detection with a retry screen
- ✅ Same-origin links stay in-app; everything else opens in the
  system browser/app
- ✅ HTTPS-enforced network security config in release builds
  (cleartext permitted only to the emulator's `10.0.2.2` alias, only
  in debug builds)
- ✅ WebView state survives rotation

## LAN auto-pairing (MikroTik only)

Still here, unconditionally attached regardless of which mode is
active — the pairing-code UI it powers (`PairingFlow` in
`InstallerWizard.jsx`) is the same component whether it's reached via
the Reseller dashboard's Routers tab or the standalone `/install`
page, so both modes benefit from it.

Lets the app pair a MikroTik router directly over the local network
instead of a human typing the pairing code into the router's console,
*if* the phone is on the same WiFi as the router. This is a genuinely
different trust model from the rest of the app — read this whole
section before turning it on for real users.

### How it works

1. Someone taps **"Pair automatically"** on the pairing screen (only
   visible inside this app — see `web-integration/LanAutoPair.jsx`).
2. `RouterLanBridge.probe()` finds the WiFi gateway IP
   (`GatewayLocator`, no location permission needed) and confirms
   something at that IP speaks RouterOS's REST API, capturing its TLS
   certificate fingerprint.
3. The UI shows that fingerprint and asks for an eyeball-check against
   the router's own sticker/console before continuing — trust-on-
   first-use (TOFU), not blind trust. See `RouterOsClient`'s doc
   comment for exactly what this does and doesn't protect against.
4. On confirm, `RouterLanBridge.pairWithConfirmedFingerprint()` pushes
   two scripts to the router via `POST /rest/execute`
   (`RouterOsScripts.kt`) — the same logic as
   `reslink-backend/router-scripts/reslink-agent.rsc`, adapted
   line-for-line, with the pairing code baked in instead of typed by
   hand. Fails closed if the router's cert changed since step 3.
5. The router registers itself with the backend exactly as it would
   in the manual flow — nothing about the backend's model changes.
   The phone never talks to the backend on the router's behalf.

### Files

| File | Purpose |
|---|---|
| `RouterOsScripts.kt` | Generates the RouterOS script text, adapted from `reslink-agent.rsc` |
| `GatewayLocator.kt` | Finds the LAN gateway IP without needing location permission |
| `RouterOsClient.kt` | TOFU HTTPS client — the security-critical piece, fails closed on cert mismatch |
| `RouterLanBridge.kt` | The `window.ReslinkNative` JS bridge — the only `addJavascriptInterface` in this app |
| `web-integration/LanAutoPair.jsx` | **Not part of the Android build.** Drop into `frontend/src/InstallerWizard.jsx` — see that file's own header for exactly where |

### Before turning this on for real users

- **Only helps MikroTik routers with `www-ssl` enabled.** Everything
  else still needs the manual/human-typed flow — `LanAutoPair` simply
  doesn't render if `probe()` isn't present or fails.
- **Requires the router's admin password**, typed in each time by
  whoever's pairing (never stored, never defaulted to blank/factory
  credentials — see the security discussion in `RouterLanBridge.kt`'s
  doc comment).
- **`RouterOsScripts.kt` inherits the same "not yet run against real
  hardware" caveat as the source `.rsc` file.** Test against a spare
  device or a Cloud Hosted Router before relying on this in the field.
- **Assumes frontend and backend share an origin** (true by default in
  this project's own `docker-compose.yml`/`nginx.conf`). If that ever
  changes, `RouterOsScripts`'s API base needs its own `BuildConfig`
  field instead of reusing `APP_BASE_URL`.

## Launcher icon and theme

Icon reuses `icon-512.png` from the web app's `manifest-admin.
webmanifest` assets — it's already the web app's "everything else"
identity, which fits an app that covers everything. The accent color
(`#6C5CE7`) is a deliberate blend between the old installer blue
(`#667eea`) and admin purple (`#764ba2`) — not pulled from any single
web manifest, since none represents this app's full scope. Swap in a
proper adaptive icon via Android Studio's Image Asset tool
(`res → New → Image Asset`) before a real store release; the current
one is single-density.

## Signed release build

Not set up — add a keystore and signing config yourself
(`Build → Generate Signed Bundle / APK` in Android Studio), keeping
credentials out of `build.gradle.kts` (env vars or a git-ignored
`keystore.properties`).

## Superseded

This replaces the three separate `reslink-installer-android`,
`reslink-reseller-android`, and `reslink-superadmin-android` projects
from earlier in this build. If you already distributed those to
anyone, they'll keep working (nothing on the backend changed) — this
is just a cleaner path going forward.
