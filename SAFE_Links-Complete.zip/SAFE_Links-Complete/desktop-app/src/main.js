// SAFE_Links desktop app — a thin native window around the whole web app
// (Super Admin, Reseller, and the Captive Portal), same "one app, routes
// you by who's signed in" philosophy as the Android app in
// safe-links-app-android/. See that project's README for the reasoning;
// it applies here unchanged.
//
// Session persistence: Electron persists localStorage/cookies per-app
// automatically (in the OS's app-data folder), the same way a real
// browser remembers you're logged into a site — no extra code needed
// for "stay signed in across restarts" to work.

const { app, BrowserWindow, shell, session, Menu } = require("electron");
const path = require("node:path");

// ---------------------------------------------------------------------
// THE ONE THING YOU MUST CHANGE: point this at your real deployed site
// before building. See README.md.
// ---------------------------------------------------------------------
const SERVER_URL = "https://REPLACE-WITH-YOUR-DOMAIN.com/";

const ALLOWED_ORIGIN = (() => {
  try {
    return new URL(SERVER_URL).origin;
  } catch {
    return null;
  }
})();

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 960,
    minHeight: 640,
    backgroundColor: "#f0f2f5",
    icon: path.join(__dirname, "..", "build", "icon.png"),
    title: "SAFE_Links",
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  buildMenu();

  mainWindow.loadURL(SERVER_URL).catch(() => showOfflineFallback());

  // If the initial or any later navigation fails (no internet, server
  // not deployed yet, DNS failure, etc.), show a local fallback page
  // instead of Electron's default blank/error screen — same reasoning
  // as the Android app's www/index.html.
  mainWindow.webContents.on("did-fail-load", (_event, errorCode) => {
    // -3 is ERR_ABORTED, which fires on normal cancelled navigations
    // (e.g. a redirect) — not a real failure, ignore it.
    if (errorCode !== -3) showOfflineFallback();
  });

  // "View receipt" / "view attachment" links throughout the app open
  // with target="_blank" — by default Electron would open those in a
  // second full app window, which looks like a bug (a second copy of
  // the whole shell) rather than "view this file". Sending them to the
  // system's own browser/PDF/image viewer instead matches what the
  // Android app does for the same links, and is what people expect for
  // "leave the app to look at a file" style links.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });

  // Basic navigation guard: only ever navigate within the configured
  // server's origin. Links that legitimately go elsewhere (there
  // aren't any in this app today) would need to be handled via
  // setWindowOpenHandler above, not by allowing arbitrary top-level
  // navigation here.
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (ALLOWED_ORIGIN && new URL(url).origin !== ALLOWED_ORIGIN) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });
}

function showOfflineFallback() {
  mainWindow.loadFile(path.join(__dirname, "offline.html"));
}

function buildMenu() {
  // A minimal menu — just enough to navigate and quit. No "Toggle
  // Developer Tools" front-and-center for a production consumer app;
  // it's still reachable via the standard OS shortcut if genuinely
  // needed for support/debugging, just not advertised in the menu.
  const template = [
    {
      label: "SAFE_Links",
      submenu: [
        { role: "reload" },
        {
          label: "Back",
          accelerator: "Alt+Left",
          click: () => { if (mainWindow.webContents.canGoBack()) mainWindow.webContents.goBack(); },
        },
        {
          label: "Forward",
          accelerator: "Alt+Right",
          click: () => { if (mainWindow.webContents.canGoForward()) mainWindow.webContents.goForward(); },
        },
        { type: "separator" },
        { role: "quit" },
      ],
    },
    {
      label: "Edit",
      submenu: [
        { role: "cut" }, { role: "copy" }, { role: "paste" }, { role: "selectAll" },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// Without this, launching the app again while it's already running (a
// double-click on the desktop icon, or Start Menu) opens a second,
// completely independent window rather than focusing the existing one
// — confusing for a business app where "am I looking at the same
// session or a different one?" actually matters. requestSingleInstanceLock()
// returns false in the SECOND process the instant it starts, so
// everything below (whenReady, window creation) only ever needs to run
// in the first/real instance — the second one just quits immediately.
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    // Support tickets can attach a voice note, recorded via the browser's
    // getUserMedia() API. Electron blocks all media-device permission
    // requests by default; this grants microphone access only to the
    // app's own configured origin — not to arbitrary sites, since nothing
    // else ever loads in this window, but worth being explicit about.
    session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
      if (permission === "media") {
        const requestingOrigin = new URL(webContents.getURL()).origin;
        callback(!ALLOWED_ORIGIN || requestingOrigin === ALLOWED_ORIGIN);
        return;
      }
      callback(false);
    });

    createWindow();

    app.on("activate", () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  });

  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") app.quit();
  });
}
