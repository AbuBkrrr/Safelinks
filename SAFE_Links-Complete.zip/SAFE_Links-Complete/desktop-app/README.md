# SAFE_Links — Windows desktop app

A native desktop window around the whole SAFE_Links web app (Super Admin,
Reseller, and the Captive Portal) — same "one app, routes you to your own
dashboard based on sign-in" idea as the Android app in
`safe-links-app-android/`. Whoever opens it sees the welcome screen if
they're not signed in, or goes straight to their own dashboard if they
are — signing in is remembered across restarts the same way a browser
remembers you're logged into a site.

Two separate tools are involved, used in order:

1. **`npm run package:win`** — builds the actual app (an Electron app,
   bundled with its own Chromium + Node runtime) into a folder of files
   including `SAFE_Links.exe`.
2. **Inno Setup Compiler** — takes that folder and produces a single
   proper Windows installer (`SAFE_Links-Setup.exe`) with a Start Menu
   entry, optional desktop icon, and an uninstaller.

You need both steps — Inno Setup packages what's already built, it
doesn't build the app itself.

## 1. Point it at your server

Open **`src/main.js`** and change this line near the top:

```js
const SERVER_URL = "https://REPLACE-WITH-YOUR-DOMAIN.com/";
```

to your real deployed domain (see the `deploy/` folder and root
`README.md` in the main SAFE_Links zip — Docker Compose + Caddy handles
deployment in one command). Do this **before** step 2 below — the URL
gets bundled into the app when it's packaged, there's no in-app settings
screen to change it later without repackaging.

## 2. Build the app

Requires [Node.js](https://nodejs.org) (any recent LTS). From this
project's folder:

```bash
npm install
npm run package:win
```

This cross-compiles a real Windows build even if you're running this on
Mac/Linux — Electron ships prebuilt per-platform runtimes, so no
Windows-specific toolchain is needed for this step specifically (Inno
Setup itself, in step 3, does need to run on Windows).

Output lands in `dist\SAFE_Links-win32-x64\` — that whole folder is the
app; `SAFE_Links.exe` is what launches it directly if you just want to
test it without building an installer yet (double-click it or run it —
no install needed to try it).

This step produces a large output folder (~350MB) — that's normal and
expected for any Electron app, not a packaging mistake. It bundles a
full Chromium + Node runtime, the same way every Electron app (Slack,
Discord, VS Code) does.

## 3. Build the installer

1. Install [Inno Setup](https://jrsoftware.org/isinfo.php) (Windows
   only — this step has to happen on a Windows machine).
2. Open **Inno Setup Compiler**.
3. `File → Open` → select **`SAFE_Links.iss`** in this project's root.
4. `Build → Compile` (or press F9).

The finished installer lands at `Output\SAFE_Links-Setup.exe`. That's
the one file you actually hand out or distribute — running it installs
SAFE_Links to the current user's Program Files (no admin rights
required by default — the installer does ask if you'd rather install
system-wide for all users instead), adds a Start Menu entry, and an
uninstaller.

`SAFE_Links.iss` expects `dist\SAFE_Links-win32-x64\` to already exist
from step 2 — if you rename or move that folder, update
`SourceBaseDir` near the top of the `.iss` file to match.

## What's already handled

I read Electron's own APIs directly to confirm each of these (not
guessed), the same way I verified things for the Android app — see the
comments in `src/main.js` for the reasoning behind each:

- **"View receipt" / "view attachment" links** (`target="_blank"`) open
  in your system's default browser/PDF/image viewer, rather than
  spawning a confusing second copy of the whole app window.
- **Voice notes on support tickets** — microphone access is granted
  only to the app's own configured domain, not to arbitrary sites
  (nothing else ever loads in this window, but worth being explicit).
- **Attaching a receipt photo/file** — needed no extra code; Electron's
  full Chromium engine already implements a native file picker for
  `<input type="file">` out of the box.
- **Session persistence** — signing in is remembered across app
  restarts automatically; Electron persists local storage per-app the
  same way a browser does per-site, no extra code needed.
- **Back/Forward navigation** — `Alt+Left` / `Alt+Right`, or the menu.
- **Single-instance lock** — opening the app while it's already running
  focuses the existing window instead of spawning a confusing second,
  independent copy.
- **Offline fallback** (`src/offline.html`) — shown if the app can't
  reach your server, instead of Electron's default blank error page.
- **App icon + installer icon** — generated from the SAFE_Links brand
  colors (`#667eea` → `#764ba2`), already wired into both the packaged
  `.exe` (via `--icon=build/icon.ico` in the `package:win` script) and
  the installer itself (`SetupIconFile` in the `.iss`).

## Honest limitation

I built and tested the `npm run package:win` step for real in the
environment I built this in — it genuinely produces a working, real
Windows `.exe` (verified: correct PE32+ format, correct bundled files,
icon embedded). What I could **not** test is the Inno Setup compile
step itself — Inno Setup is a Windows-only GUI tool with no command-line
equivalent available to me, so `SAFE_Links.iss` is written carefully
against Inno Setup's documented, stable scripting format, but its first
real compile in the actual Inno Setup Compiler is the true test. If it
throws an error, the line number it reports will point at the exact
line to look at — the syntax here is standard enough that any issue
should be small and obvious to fix.

## Windows SmartScreen warning (expected, not a bug)

The first time someone runs `SAFE_Links-Setup.exe` on a machine that
hasn't seen it before, Windows will very likely show a blue "Windows
protected your PC" SmartScreen warning, since the installer isn't
digitally code-signed. This isn't a mistake in the build — it's the
same thing every unsigned Windows app triggers, and it's the direct
equivalent of Android's "install from unknown sources" prompt for the
APK. There's a "More info → Run anyway" link to get past it.

The only real fix is a code-signing certificate from a certificate
authority (DigiCert, Sectigo, etc.) — typically a paid yearly
subscription, and (like the Android release keystore) something you'd
need to obtain and hold yourselves, not something I can generate or
embed on your behalf. Signing removes the warning and is worth doing
before wide distribution, but isn't required to install and run the
app.
