package com.aibrainsventures.safelinks;

import android.os.Bundle;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // The web app opens "view receipt" / "view attachment" links (payment
        // proofs, support-ticket attachments) with target="_blank" — a plain
        // Android WebView silently does nothing with those unless something
        // handles onCreateWindow, AND setSupportMultipleWindows(true) is
        // set (Capacitor's own Bridge does not enable this by default —
        // without it, onCreateWindow never fires at all, regardless of
        // what WebChromeClient is installed). ExternalLinkWebChromeClient
        // adds the onCreateWindow handling (opens the link in the device's
        // own browser/PDF/image viewer) while extending Capacitor's own
        // BridgeWebChromeClient, so everything Capacitor already handles by
        // default — the mic permission prompt for voice notes, the native
        // file picker for attachments, JS alerts/confirms — keeps working
        // unchanged.
        this.bridge.getWebView().getSettings().setSupportMultipleWindows(true);
        this.bridge.getWebView().setWebChromeClient(new ExternalLinkWebChromeClient(this.bridge));

        // Capacitor's BridgeActivity does NOT handle the hardware/gesture
        // back button at all — without this, pressing back at ANY point
        // (mid-way through the Captive Portal's plan -> pay -> confirm
        // flow, a half-filled signup form, a support ticket reply box)
        // would immediately exit the whole app instead of stepping back
        // within it, which is what every other back button everywhere
        // else on the phone does. This makes back navigate the WebView's
        // own history first, and only actually exits the app once
        // there's no WebView history left to go back to.
        getOnBackPressedDispatcher().addCallback(
            this,
            new OnBackPressedCallback(true) {
                @Override
                public void handleOnBackPressed() {
                    if (bridge.getWebView().canGoBack()) {
                        bridge.getWebView().goBack();
                    } else {
                        setEnabled(false);
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }
            }
        );
    }
}
