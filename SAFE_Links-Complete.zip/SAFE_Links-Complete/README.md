# SAFE_Links — complete package

A product of A I Brains Ventures. This zip has everything built so far:
the actual web application, native Android and Windows apps that wrap
it, and a clickable offline demo. Each piece has its own detailed
README — this file is just the map.

## Start here: deployment order matters

The Android and Windows apps are **empty shells without the web app
deployed somewhere first** — they're just windows that load a URL. Build
in this order:

1. **`web-app/`** — deploy this first. It's the actual system: the
   Node/Postgres backend and the React frontend (Super Admin dashboard,
   Reseller dashboard, Captive Portal). See `web-app/README.md` and
   `web-app/deploy/README.md` — Docker Compose + Caddy gets you a live
   HTTPS domain in one command.
2. **`android-app/`** — once step 1 is live, edit
   `android-app/capacitor.config.json` with your real domain, then open
   `android-app/android/` in Android Studio. See `android-app/README.md`.
3. **`desktop-app/`** — same idea for Windows: edit
   `desktop-app/src/main.js` with your real domain, run
   `npm run package:win`, then compile `desktop-app/SAFE_Links.iss` in
   Inno Setup Compiler. See `desktop-app/README.md`.

One app, one login system — a person signs in once on any of these
(web, Android, or Windows) and lands on their own dashboard based on
their account role. There's no separate "installer-only" app anymore;
the router-pairing wizard lives inside the same app as everything else,
reachable from the welcome screen.

## `system-demo/`

A single self-contained HTML file — open it directly in any browser,
no server or deployment needed. Click through mocked versions of all
three surfaces (Reseller Admin, Super Admin, Captive Portal) with fake
data, useful for showing someone what the system looks like before it's
actually deployed anywhere. Nothing in it reads from or writes to your
real system.

## What's been fixed / added, most recent first

- Desktop app: single-instance lock (launching while already running
  now focuses the existing window instead of opening a duplicate).
- Android app: four native-layer gaps fixed beyond the default
  Capacitor scaffold — "view receipt" links now actually open,
  voice-note recording permission properly declared, hardware back
  button navigates within the app instead of exiting it, keyboard no
  longer covers input fields on forms.
- Android app converted from an installer-only app to the universal
  app described above.
- Full SAFE_Links rebrand (was "Reslink") — every user-visible string,
  the platform's default support contact, license payee name.
- Real file/voice-note upload support on every support-ticket surface.
- Fixed: a crash on the Super Admin Referrals tab (a missing state
  declaration — `editingBonusId` was used but never initialized).
- Fixed: server errors no longer leak internal error text to the
  client; full detail still goes to your server log.
- Fixed: negative-price validation gap on reseller voucher plans.

## Support

A I Brains Ventures — aibrainsventures@gmail.com — +234 803 254 0215
